<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateReportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reports', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('nama_pemilik');
            $table->string('no_hp');
            $table->string('nama_kendaraan');
            $table->string('surat_spkt');
            $table->string('jenis');
            $table->string('warna')->nullable();
            $table->string('foto_kendaraan');
            $table->string('foto_stnk');
            $table->string('foto_bpkb');
            $table->string('no_rangka')->nullable();
            $table->string('plat')->nullable();
            $table->string('no_mesin')->nullable();
            $table->string('slug');
            $table->string('deskripsi')->nullable();
            $table->enum('status', ['Ditemukan', 'Belum Ditemukan', 'Pending'])->default('Pending');
            $table->timestamps();

        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('reports');
    }
}
