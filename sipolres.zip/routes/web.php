<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home');
Route::get('/tentang', 'HomeController@tentang')->name('tentang');
Route::get('/search', 'HomeController@search')->name('search');
Route::get('/kategori/mobil', 'HomeController@indexMobil')->name('indexMobil');
Route::get('/kategori/motor', 'HomeController@indexMotor')->name('indexMotor');

Route::get('/motor/{slug}', 'HomeController@showMotor')->name('showMotor');
Route::get('/mobil/{slug}', 'HomeController@showMobil')->name('showMobil');


Auth::routes();

Route::get('/account/settings', 'HomeController@settingsAccount')->name('settingsAccount')->middleware('admin');
Route::put('/account/settings', 'HomeController@updateAccount')->name('updateAccount')->middleware('admin');
// Route::get('/home', 'HomeController@index')->name('home');

Route::get('/admin/dashboard', 'AdminController@index')->name('admin.dashboard')->middleware('admin');


Route::get('/admin/data-admin', 'AdminController@admin')->name('adminData')->middleware('admin');
Route::get('/admin/add-admin', 'AdminController@addAdmin')->name('adminAdd')->middleware('admin');
Route::post('/admin/add-admin', 'AdminController@storeAdmin')->name('adminStore')->middleware('admin');
Route::get('/admin/add-laporan', 'AdminController@addLaporan')->name('adminAddLaporan')->middleware('admin');
Route::post('/admin/add-laporan', 'AdminController@storeLaporan')->name('adminStoreLaporan')->middleware('admin');

Route::put('/admin/update-pelapor/{id}', 'AdminController@updatePelapor')->name('updatePelapor')->middleware('admin');

Route::get('/admin/data-laporan', 'AdminController@laporan')->name('admin.dataLaporan')->middleware('admin');
Route::put('/admin/edit-laporan/{id}', 'AdminController@updateLaporan')->name('adminUpdateLaporan')->middleware('admin');


Route::get('/pelapor/dashboard', 'PelaporController@index')->name('pelapor.dashboard')->middleware('pelapor');
Route::get('/pelapor/add-laporan', 'PelaporController@addLaporan')->name('pelaporAddLaporan')->middleware('pelapor');
Route::post('/pelapor/add-laporan', 'PelaporController@storeLaporan')->name('pelaporStoreLaporan')->middleware('pelapor');
Route::delete('/pelapor/destroy-laporan/{laporan}', 'PelaporController@destroyLaporan')->name('pelaporDestroyLaporan')->middleware('pelapor');


Route::get('/home', 'HomeController@index')->name('home');
    