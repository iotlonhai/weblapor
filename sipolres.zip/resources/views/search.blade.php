@extends('layouts.home')
@section('content')
<div class="uk-background-muted">
    <div class="uk-container uk-padding">
        <p class="uk-text-center">
            <span class="uk-h2">HASIL PENCARIAN</span><hr><br>
        </p>
        <div class="uk-child-width-1-4@m uk-grid-match" uk-grid>
            @foreach ($reports as $report)
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-media-top">
                            <img src="{{ url('img/kendaraan',$report->foto_kendaraan) }}" alt="">
                        </div>
                        <div class="uk-card-body">
                            <h3 class="uk-card-title">{{ $report->nama_kendaraan }}</h3>
                            <p>
                                <b>Jenis: </b>{{$report->jenis}}<br>
                                <b>Warna: </b>{{$report->warna}}<br>
                                <b>No Polisi: </b>{{$report->plat}}<br>
                            </p>
                            @if($report->status == 'Belum Ditemukan')
                                <span class="uk-label uk-label-danger">{{ $report->status }}</span>
                            @else
                                <span class="uk-label">{{ $report->status }}</span>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endsection