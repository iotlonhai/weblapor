@extends('layouts.app')
@section('content')
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<form action="{{route('pelaporStoreLaporan')}}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="uk-margin uk-width-1-2@s">
        <div class="uk-margin"  uk-form-custom="target: true">
            <input name="foto_stnk" type="file" required>
            <input class="uk-input uk-form-width-medium" type="text" placeholder="Foto STNK" disabled>
            <button class="uk-button uk-button-default">Foto STNK</button>
        </div>
        <div class="uk-margin"  uk-form-custom="target: true">
            <input name="foto_bpkb" type="file" required>
            <input class="uk-input uk-form-width-medium" type="text" placeholder="Foto BPKB" disabled>
            <button class="uk-button uk-button-default">Foto BPKB</button>
        </div>
        <div class="uk-margin"  uk-form-custom="target: true">
            <input name="foto_kendaraan" type="file" required>
            <input class="uk-input uk-form-width-medium" type="text" placeholder="Foto Kendaraan" disabled>
            <button class="uk-button uk-button-default">Foto Kendaraan</button>
        </div>
    </div>
    <div class="uk-grid-small" uk-grid>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Nama Pemilik</label>
            <input class="uk-input" name="nama_pemilik" type="text" placeholder="Nama sesuai STNK" value="{{ old('nama_pemilik') }}"required>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Hp Pemilik</label>
            <input class="uk-input  uk-width-expand" id="phname" name="no_hp" type="telp" placeholder="Contoh: 62813768xxxxx" value="{{ old('phname') }}"required>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Nama Kendaraan</label>
            <input class="uk-input" name="nama_kendaraan" type="text" placeholder="Nama kendaraan sesuai STNK" value="{{ old('nama_kendaraan') }}" required>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Warna Kendaraan</label>
            <input class="uk-input" name="warna" type="text" placeholder="Warna kendaraan sesuai STNK" value="{{ old('warna') }}" required>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Rangka</label>
            <input class="uk-input" name="no_rangka" type="text" placeholder="Nomor rangka kendaraan sesuai STNK" value="{{ old('no_rangka') }}" required>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Polisi</label>
            <input class="uk-input" name="plat" type="text" placeholder="Nomor polisi kendaraaan sesuai STNK" value="{{ old('plat') }}" required>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Mesin</label>
            <input class="uk-input" name="no_mesin" type="text" placeholder="Nomor mesin kendaraan sesuai STNK" value="{{ old('no_mesin') }}" required>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Jenis Kendaraan</label>
            <select name="jenis" class="uk-select" required>
                <option value="">Pilih Jenis Kendaraan</option>
                <option value="Sepeda Motor">Sepeda Motor</option>
                <option value="Mobil">Mobil</option>
            </select>
        </div>
    </div>
    <div class="uk-margin">
        <label class="uk-form-label" for="form-stacked-text">Deskripsi</label>
        <textarea class="uk-textarea" name="deskripsi" rows="5" placeholder="Ceritakan kronologi kejadian pencurian" required></textarea>
    </div>
    <div class="uk-align-right">
        <input class="uk-button uk-button-kimia uk-margin-top uk-align-right" type="submit" value="Add">
    </div>
</form>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$().ready(() => {
  var maskOptions = {
    placeholder: "+62 ____________",
    onKeyPress: function(cep, e, field, options) {
      // Use an optional digit (9) at the end to trigger the change
      var masks = ["+62 00000000000", "+62 000000000000"],
        digits = cep.replace(/[^0-9]/g, "").length,
        // When you receive a value for the optional parameter, then you need to swap
        // to the new format
        mask = digits <= 12 ? masks[0] : masks[1];

      $("#phname").mask(mask, options);
    }
  };

  $("#phname").mask("+62 00000000000", maskOptions);
});
</script>
@endsection
