@extends('layouts.app')
@section('content')
        <a class="uk-button uk-button-text uk-align-right uk-margin-medium-right" href="{{route('pelaporAddLaporan')}}"><span uk-icon="plus"></span> Add Laporan</a>
    </p>
    <h4 class="uk-text-center">DATA LAPORAN</h4>
    <div class="uk-overflow-auto">
        <table id="table" class="uk-table uk-table-striped uk-table-hover">
            <thead>
                <tr>
                    <th>Nama Pelapor</th>
                    <th class="uk-visible@l">Jenis Kendaraan</th>
                    <th>No Polisi</th>
                    <th>Tanggal Lapor</th>
                    <th>Status</th>
                    <th class="uk-width-small">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($laporan as $key => $lapor)
                    <tr>
                    <td><button uk-toggle="target: #a{{++$key}}" class="uk-align-left uk-button uk-button-text uk-text-center">{{$lapor->nama_pemilik}}</button></td>
                        <td class="uk-visible@l">{{$lapor->jenis}}</td>
                        <td>{{$lapor->plat}}</td>
                        <td>{{$lapor->created_at->format('d-F-Y')}}</td>
                        <td>{{$lapor->status}}</td>
                        <td>
                            <form action="{{ route('pelaporDestroyLaporan', $lapor) }}" method="post">
                            @csrf
                                {{ method_field('DELETE') }}
                                <input class="uk-button uk-button-text uk-text-danger" type="submit" onclick="alert('Anda yakin hapus laporan dari {{$lapor->nama_pemilik}}?')" value="DELETE">
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    @foreach($laporan as $key => $lapor)
    <div id="a{{++$key}}" class="uk-modal-container" uk-modal>
        <div class="uk-border-rounded uk-modal-dialog uk-modal-body">
            <button class="uk-modal-close-default" type="button" uk-close></button>
            <h2 class="uk-modal-title">{{$lapor->name}}</h2>
            <div class="uk-child-width-1-2@m" uk-grid>
                <div class="uk-width-medium">
                    <a href="{{asset('img/kendaraan/'.$lapor->foto_kendaraan)}}" target="_blank" class="uk-button"> Foto Kendaraan</a><br>
                    <a href="{{asset('img/stnk/'.$lapor->foto_stnk)}}" target="_blank" class="uk-button"> Foto STNK</a><br>
                    <a href="{{asset('img/bpkb/'.$lapor->foto_bpkb)}}" target="_blank" class="uk-button"> Foto BPKB</a><br>
                </div>
                <div class="uk-width-expand">
                    <p>
                        <b>Nama Pemilik: </b>{{$lapor->nama_pemilik}}<br>
                        <b>No Hp Pemilik: </b>{{$lapor->no_hp}}<br>
                        <b>Nama Kendaraan: </b>{{$lapor->nama_kendaraan}}<br>
                        <b>Jenis Kendaraan: </b>{{$lapor->jenis}}<br>
                        <b>Warna Kendaraan: </b>{{$lapor->warna}}<br>
                        <b>No Rangka: </b>{{$lapor->no_rangka}}<br>
                        <b>No Mesin: </b>{{$lapor->no_mesin}}<br>
                        <b>No Polisi: </b>{{$lapor->plat}}<br>
                        <b>Status: </b>{{$lapor->status}}<br>
                    </p>
                </div>
                
                
            </div>
            <b>Track: </b>
            <ol class="progtrckr" data-progtrckr-steps="4">
            <li class="progtrckr-done">Pending</li>
             <li class="@if($lapor->status == 'Proses' || $lapor->status == 'Ditemukan' || $lapor->status == 'Diambil' ) progtrckr-done @else progtrckr-todo @endif">Proses</li>
             <li class="@if($lapor->status == 'Ditemukan' || $lapor->status == 'Diambil') progtrckr-done @else progtrckr-todo @endif">Di Temukan</li>
             <li class="@if($lapor->status == 'Diambil') progtrckr-done @else progtrckr-todo @endif"">Di Ambil</li>
            </ol>
            <br>
        </div>
    </div>
    @endforeach
@endsection