@extends('layouts.app')
@section('content')
    <h3 class="uk-text-center">Data Pelaporan</h3>
    <div class="uk-margin-left uk-child-width-expand@m " uk-grid>
        <div class="uk-border-rounded uk-align-left uk-width-xxlarge uk-card uk-card-default uk-card-body">
            <div class="uk-child-width-1-4@m uk-text-center uk-margin-bottom" uk-grid>
                <div>
                    <h3>Hari Ini</h3>
                    <p>{{ $reportToday }}</p>
                </div>
                <div>
                    <h3>Motor</h3>
                    <p>{{ $reportMotor }}</p>
                </div>
                <div>
                    <h3>Mobil</h3>
                    <p>{{ $reportMobil }}</p>
                </div>
                <div>
                    <h3>Ditemukan</h3>
                    <p>{{ $reportDitemukan }}</p>
                </div>
            </div>
        </div>
        <div class="uk-border-rounded uk-align-left uk-text-center uk-width-expand uk-card uk-card-default uk-card-body">
            <div>
                <h3>All</h3>
                <p>{{ $reportAll }}</p>
            </div>
        </div>
    </div>
    
    <div class="uk-align-center" >
        <canvas id="myChart"></canvas>
    </div>
    <script>
        var config = {
            type: 'line',
            data: {
                labels: [@foreach($chartDatas as $d) "{{ $d['date'] }}", @endforeach],
                datasets: [{
                    label: 'Mobil',
                    backgroundColor : "rgba(252, 172, 44,0.0)",
                    borderColor: "rgba(252,172,44,0.8)",
                    pointBackgroundColor: "rgba(252,172,44,1)",
                    pointBorderColor: "rgba(0,0,0,1)",
                    fill: true,
                    data: [
                        @foreach($chartDatas as $d) "{{ $d['dataMobil'] }}", @endforeach
                    ],
                }, {
                    label: 'Sepeda Motor',
                    backgroundColor : "rgba(102, 204, 255,0.3)",
                    borderColor : "rgba(102, 204, 255,0.8)",
                    pointBackgroundColor: "rgba(102, 204, 255,1)",
                    pointBorderColor: "rgba(0,0,0,1)",
                    fill: true,
                    data: [
                        @foreach($chartDatas as $d) "{{ $d['dataMotor'] }}", @endforeach
                    ],
                }]
            },
            options: {
                responsive: true,
                tooltips: {
                    mode: 'index',
                    intersect: false,
                },
                hover: {
                    mode: 'nearest',
                    intersect: true
                },
                scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'Month'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        ticks: {
                            max: 30,
                            stepSize: 5,
                            },
                        scaleLabel: {
                            display: true,
                        }
                    }]
                }
            }
        };

        window.onload = function() {
            var ctxl = document.getElementById('myChart').getContext('2d');
            window.myLine = new Chart(ctxl, config);
        };
    </script>
@endsection