@extends('layouts.app')
@section('content')
        <a class="uk-button uk-button-text uk-align-right uk-margin-medium-right" href="{{route('adminAdd')}}"><span uk-icon="plus"></span> Add User</a>
    </p>

    <h4 class="uk-text-center">DATA USER</h4>
    <ul uk-accordion>
        <li>
            <a class="uk-accordion-title" href="#">Admin</a>
            <div class="uk-accordion-content">
                <table class="uk-table uk-table-hover uk-table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>NIP</th>
                            <th>Email</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($admins as $key => $admin)
                            <tr>
                            <td class="uk-text-capitalize">{{$admin->name}}</td>
                                <td>{{$admin->nip}}</td>
                                <td>{{$admin->admin_has_user->email}}</td>
                                <td>{{$admin->phone}}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </li>
        <li>
            <a class="uk-accordion-title" href="#">Pelapor</a>
            <div class="uk-accordion-content">
                <table class="uk-table uk-table-hover uk-table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>KTP</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($pelapor as $key => $lapor)
                            <tr>
                                <td><button uk-toggle="target: #a{{++$key}}" class="uk-align-left uk-button uk-button-text uk-text-center">{{$lapor->name}}</button></td>
                                <td class="uk-text-capitalize">{{$lapor->no_ktp}}</td>
                                <td>{{$lapor->pelapor_has_user->email}}</td>
                                <td>{{$lapor->phone}}</td>
                                <td class="uk-text-capitalize">{{$lapor->pelapor_has_user->status}}</td>
                                <td>
                                    <form action="{{ route('updatePelapor', $lapor) }}" method="post">
                                        @csrf
                                            {{ method_field('PUT') }}
                                            <input name="status" class="uk-button uk-button-text uk-text-success" type="submit" value="Active"><br>
                                            <input name="status" class="uk-button uk-button-text uk-text-danger" type="submit" value="Banned">
                                        </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </li>
    </ul>
    @foreach($pelapor as $key => $lapor)
    <div id="a{{++$key}}" uk-modal>
        <div class="uk-border-rounded uk-modal-dialog uk-modal-body">
            <button class="uk-modal-close-default" type="button" uk-close></button>
            <h2 class="uk-modal-title">{{$lapor->name}}</h2>
            <div class="uk-child-width-1-2@m" uk-grid>
                <div class="uk-width-medium">
                    <img src="{{url('img/ktp/'.$lapor->foto_ktp)}}">
                </div>
                <div class="uk-width-expand">
                    <p>
                        <b>Nama: </b>{{$lapor->name}}<br>
                        <b>Nomor Ktp: </b>{{$lapor->no_ktp}}<br>
                        <b>Nomor Hp: </b>{{$lapor->phone}}<br>
                        <b>Alamat: </b>{{$lapor->alamat}}<br>
                        <b>Status: </b>{{$lapor->pelapor_has_user->status}}<br>
                    </p>
                </div>
            </div>
        </div>
    </div>
    @endforeach    
@endsection
