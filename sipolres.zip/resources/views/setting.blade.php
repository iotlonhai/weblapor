@extends('layouts.app')
@section('content')
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<div class="uk-position-center uk-padding-large">
    <h3 class="uk-text-uppercase">UPDATE {{$admin->name}}</h3>
    <form action="{{route('updateAccount')}}" method="POST" enctype="multipart/form-data">
        @csrf
        {{ method_field('PUT') }}
        <div class="uk-grid-small" uk-grid>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">Name</label>
            <input class="uk-input" name="name" type="text" value="{{$admin->user_has_admin->name}}" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">Email Address</label>
                <input class="uk-input" name="email" type="text" value="{{$admin->email}}" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">NIP</label>
                <input class="uk-input" name="nip" type="text" value="{{$admin->user_has_admin->nip}}" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">Phone</label>
                <input class="uk-input" name="phone" type="text" value="{{$admin->user_has_admin->phone}}" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">Old Password</label>
                <input class="uk-input" name="oldPassword" type="password" placeholder="Old Password" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">New Password</label>
                <input type="password" class="uk-input" name="newPassword" placeholder="New Password">
            </div>
            <div class="uk-width-1-2@s">
                <input class="uk-button uk-button-kimia uk-margin-top uk-align-right" type="submit" value="Add">
            </div>
        </div>
    </form>
</div>
@endsection
