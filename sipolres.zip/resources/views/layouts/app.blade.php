<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/uikit.min.js') }}" defer></script>
    <script src="{{ asset('js/uikit-icons.min.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/uikit.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/main.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.uikit.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.uikit.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
</head>

<body>
    <button class="uk-hidden@l uk-margin-small-left uk-margin-small-top uk-button uk-button-default uk-border-rounded" type="button"
        uk-toggle="target: #offcanvas-push"><span uk-icon="menu"></span> Menu</button>
    <div class="uk-child-width-1-2@m" style="background: #252A41" uk-height-viewport="offset-top: false" uk-grid>
        <div class="uk-visible@l uk-width-1-4 uk-light uk-inline">
            <div class="uk-text-center" uk-sticky="offset: 70;">
                <p>
                    <span class="uk-h3 uk-text-capitalize">Hi <a href="{{ route(auth()->user()->role.'.dashboard') }}">{{ auth()->user()->role }}</a></span><br>
                </p>
                <p class="uk-text-small">Welcome back to the workspace!</p>
                <div class="uk-grid-small uk-margin-medium-right uk-margin-medium-left" uk-grid>
                    @if(auth()->user()->role == 'admin')
                   <div class="uk-width-1-2">
                        <a href="{{ route(auth()->user()->role.'.dataLaporan') }}">
                            <img class="uk-width-4-5 uk-border-rounded" src="{{url('img/reportIcon.png')}}" alt="">
                        </a>
                        <p>Data Laporan</p>
                    </div>
                        <div class="uk-width-1-2">
                            <a href="{{ route('adminData') }}">
                                <img class="uk-width-4-5 uk-border-rounded" src="{{url('img/adminIcon.png')}}" alt="">
                            </a>
                            <p>Data User</p>
                        </div>
                        <div class="uk-width-1-2">
                            <a href="{{route('settingsAccount')}}">
                                <img class="uk-width-4-5 uk-border-rounded" src="{{ asset('img/settingsIcon.png')}}" alt="">
                            </a>
                            <p>Settings</p>
                        </div>
                        @endif
                        <div class="uk-width-1-2 @if(auth()->user()->role == 'pelapor') uk-align-center @endif">
                            <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <img class="uk-width-4-5 uk-border-rounded" src="{{ asset('img/logout.png')}}" alt="">
                            </a>
                            <p>Log Out</p>
                        </div>
                </div>
            </div>
        </div>
        <div class="uk-width-expand uk-background-muted uk-padding uk-border-rounded uk-inline">
            @if(Request::url() != url('admin/dashboard') && Request::url() != url('pelapor/dashboard'))
                <p class="uk-margin-small-top">
                    <a class="uk-button uk-button-text" href="{{ route(auth()->user()->role.'.dashboard') }}"><span uk-icon="chevron-left"></span> Back</a>
            @endif 
            @if(auth()->user()->status == 'aktif')  
            @yield('content')
            @elseif(auth()->user()->status == 'ditolak')
            <div class="uk-position-center uk-text-center">
                <h1>
                    AKUN ANDA DITOLAK
                </h1>
                <p>Mohon untuk mendaftar ulang</p>
            </div>
            @else
            <div class="uk-position-center uk-text-center">
                <h1>
                    AKUN BELUM AKTIF
                </h1>
                <p>Mohon menunggu maksimal 1x24 jam hari kerja </p>
            </div>
            @endif
        </div>
    </div>
    <div id="offcanvas-push" uk-offcanvas="mode: push; overlay: true">
            <div class="uk-offcanvas-bar">
                <button class="uk-offcanvas-close" type="button" uk-close></button>
                <div class="uk-text-center uk-position-center">
                    <p>
                        <span class="uk-h3 uk-text-capitalize">Hi <a href="{{ route(auth()->user()->role.'.dashboard') }}">{{ auth()->user()->role }}</a></a></span><br>
                        <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><span uk-icon="icon: sign-out"></span> Logout</a>
                    </p>
                    <p class="uk-text-small">Welcome back to the workspace<br>We missed You!</p>
                    <div class="uk-grid-small uk-margin-medium-right uk-margin-medium-left" uk-grid>
                        @if(auth()->user()->role == 'admin')
                        <div class="uk-width-1-2">
                            <a href="{{ route(auth()->user()->role.'.dataLaporan') }}" class="uk-button-text">
                                <img class="uk-width-4-5 uk-border-rounded" src="{{ asset('img/mesjidIcon.png')}}" alt="">
                                Data Laporan
                            </a>
                        </div>
                        <div class="uk-width-1-2">
                            <a href="{{ route('adminData') }}" class="uk-button-text">
                                <img class="uk-width-4-5 uk-border-rounded" src="{{ asset('img/adminIcon.png')}}" alt="">
                                Data Admin
                            </a>
                        </div>
                        <div class="uk-width-1-2">
                            <a href="" class="uk-button-text">
                            <img class="uk-width-4-5 uk-border-rounded" src="{{ asset('img/reportIcon.png')}}" alt="">
                            Report
                            </a>
                        </div>
                        <div class="uk-width-1-2">
                            <a href="{{route('settingsAccount')}}" class="uk-button-text">
                            <img class="uk-width-4-5 uk-border-rounded" src="{{ asset('img/settingsIcon.png')}}" alt="">
                            Settings
                            </a>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            @csrf
        </form>
    <script>
        function printData()
            {
            var divToPrint=document.getElementById("table");
            newWin= window.open("");
            newWin.document.write(divToPrint.outerHTML);
            newWin.print();
            newWin.close();
            }

            $('#print').on('click',function(){
                printData();
            })
        $(document).ready(function() {
            $('#table').DataTable({
                "order": [[ 3, "desc" ]],
                "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
            });
        } );
        $('#time').timepicker({ 
            timeFormat: 'H:mm',
            interval: 15
        });
    </script>
    
</body>

</html>