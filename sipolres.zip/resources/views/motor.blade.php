@extends('layouts.home')
@section('content')
<div class="uk-background-muted">
    <div class="uk-container uk-padding">
        <p class="uk-text-center">
            <span class="uk-h2">SEPEDA MOTOR</span><br>
        </p>
        <div class="uk-child-width-1-4@m uk-grid-match" uk-grid>
            @foreach ($sepeda_motor as $sepmor)
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-media-top">
                            <img src="{{ url('img/kendaraan',$sepmor->foto_kendaraan) }}" alt="">
                        </div>
                        <div class="uk-card-body">
                            <h3 class="uk-card-title">{{ $sepmor->nama_kendaraan }}</h3>
                            <p>
                                <b>Jenis: </b>{{$sepmor->jenis}}<br>
                                <b>Warna: </b>{{$sepmor->warna}}<br>
                                <b>No Polisi: </b>{{$sepmor->plat}}<br>
                            </p>
                            @if($sepmor->status == 'Belum Ditemukan')
                                <span class="uk-label uk-label-danger">{{ $sepmor->status }}</span>
                            @else
                                <span class="uk-label">{{ $sepmor->status }}</span>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        <div class="uk-padding uk-align-right">

            {{ $sepeda_motor->links() }}
        </div>

    </div>
</div>
@endsection