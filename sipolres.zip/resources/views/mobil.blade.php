@extends('layouts.home')
@section('content')
<div class="uk-background-muted">
    <div class="uk-container uk-padding">
        <p class="uk-text-center">
            <span class="uk-h2">MOBIL</span><br>
        </p>
        <div class="uk-child-width-1-4@m uk-grid-match" uk-grid>
            @foreach ($mobil as $mob)
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-media-top">
                            <img src="{{ url('img/kendaraan',$mob->foto_kendaraan) }}" alt="">
                        </div>
                        <div class="uk-card-body">
                            <h3 class="uk-card-title">{{ $mob->nama_kendaraan }}</h3>
                            <p>
                                <b>Jenis: </b>{{$mob->jenis}}<br>
                                <b>Warna: </b>{{$mob->warna}}<br>
                                <b>No Polisi: </b>{{$mob->plat}}<br>
                            </p>
                            @if($mob->status == 'Belum Ditemukan')
                                <span class="uk-label uk-label-danger">{{ $mob->status }}</span>
                            @else
                                <span class="uk-label">{{ $mob->status }}</span>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endsection