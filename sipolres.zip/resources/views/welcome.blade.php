@extends('layouts.home')
@section('content')
<div class="uk-background-muted">
    <div class="uk-background-cover" style="background-position: 0% 60%;background-image: url('http://127.0.0.1:8000/img/depan.jpeg');" uk-height-viewport="offset-top: true">
        <div class="uk-align-center uk-padding uk-width-1-2@m" uk-scrollspy="cls: uk-animation-slide-left; repeat: false">
            <div class=" uk-text-center uk-border-rounded uk-overlay uk-overlay-primary">
                <h1>
                    <span style="color:#FDC42F">TURN BACK </span>
                    CRIME 
                </h1>
                <p class="uk-h3">TOGETHER WE CAN</p>
            </div>
            
        </div>
    </div>
    <div class="uk-container-small uk-align-center">
        <div class="uk-text-center">
            <div class="uk-child-width-expand@s uk-text-center uk-grid-match" uk-grid>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <p class="uk-h4">KENDARAAN MOTOR</p>
                        <hr style="border: 1px solid black">
                        <p class="uk-h4">{{ count($reportMotor) }}</p>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <p class="uk-h4">KENDARAAN MOBIL</p>
                        <hr style="border: 1px solid black">
                        <p class="uk-h4">{{ count($reportMobil) }}</p>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <p class="uk-h4">KASUS SELESAI</p>
                        <hr style="border: 1px solid black">
                        <p class="uk-h4">{{ count($reportDitemukan) }}</p>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <p class="uk-h4">KASUS BERJALAN</p>
                        <hr style="border: 1px solid black">
                        <p class="uk-h4">{{ count($reportBelum) }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="uk-container">
        <p class="uk-text-center">
            <span class="uk-h2">TELAH HILANG</span><br>
        </p>
        <div class="uk-child-width-1-4@m uk-grid-match" uk-grid>
            @foreach ($reportBelum->slice(0, 4) as $rb)
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-media-top">
                            <img src="{{ url('img/kendaraan',$rb->foto_kendaraan) }}" alt="">
                        </div>
                        <div class="uk-card-body">
                            <h3 class="uk-card-title">{{ $rb->nama_kendaraan }}</h3>
                            <p>
                                <b>Jenis: </b>{{$rb->jenis}}<br>
                                <b>Warna: </b>{{$rb->warna}}<br>
                                <b>No Polisi: </b>{{$rb->plat}}<br>
                            </p>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
    <hr>
    <div class="uk-margin uk-container">
        <p class="uk-text-center">
            <span class="uk-h2">TELAH DITEMUKAN</span><br>
        </p>
        <div class="uk-child-width-1-4@m uk-grid-match" uk-grid>
            @foreach ($reportDitemukan->slice(0, 4) as $rd)
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-media-top">
                            <img src="{{ url('img/kendaraan',$rd->foto_kendaraan) }}" alt="">
                        </div>
                        <div class="uk-card-body">
                            <h3 class="uk-card-title">{{ $rd->nama_kendaraan }}</h3>
                            <p>
                                <b>Jenis: </b>{{$rd->jenis}}<br>
                                <b>Warna: </b>{{$rd->warna}}<br>
                                <b>No Polisi: </b>{{$rd->plat}}<br>
                            </p>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endsection