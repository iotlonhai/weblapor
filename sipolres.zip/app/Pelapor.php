<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pelapor extends Model
{
    protected $table = 'pelapor';
    public function pelapor_has_user()
    {
        return $this->belongsTo('App\User', 'userId');
    }
}
