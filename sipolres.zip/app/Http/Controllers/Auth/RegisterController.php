<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\Pelapor;
use Auth;
class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo;
    public function redirectTo()
    {
        switch(Auth::user()->role){
            case 'admin':
            $this->redirectTo = '/admin/dashboard';
            return $this->redirectTo;
                break;
            case 'pelapor':
                    $this->redirectTo = '/pelapor/dashboard';
                return $this->redirectTo;
                break;
            default:
                $this->redirectTo = '/login';
                return $this->redirectTo;
        }
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'phone' => ['required'],

        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $user = new User;
        $user->email = $data['email'];
        $user->password = Hash::make($data['password']);
        $user->role = 'pelapor';
        $user->save();

        $fotoKtp = $data['foto_ktp'];
        $nameKtp = rand(3000,999999).$fotoKtp->getClientOriginalName();
        $destinationPath = public_path().'/img/ktp/';
        $fotoKtp->move($destinationPath,$nameKtp);

        $phone = str_replace('+', '', $data['phone']);
        $pelapor = new Pelapor;
        $pelapor->userId = $user->id;
        $pelapor->name = $data['name'];
        $pelapor->no_ktp = $data['no_ktp'];
        $pelapor->alamat = $data['alamat'];
        $pelapor->foto_ktp = $nameKtp;
        $pelapor->phone = $phone;
        $pelapor->save();

        return $user;
    }
}
