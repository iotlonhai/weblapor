<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\User;
use App\Admin;
use App\Pelapor;
use App\Report;
use Storage;
use Hash;
use Auth;
use Facades\Yugo\SMSGateway\Interfaces\SMS;
use Carbon\Carbon;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(){
        $reportToday = Report::whereDay('created_at', date('d'))->count();
        $reportMotor = Report::where('jenis', 'Sepeda Motor')->count();
        $reportMobil = Report::where('jenis', 'Mobil')->count();
        $reportDitemukan = Report::where('status', 'Ditemukan')->count();
        $reportAll = Report::where('status', '!=', 'Pending')->count();
        $start = Carbon::now()->subMonth(5);
        $dates = [];
        $chartDatas = [];
        $shipping = 0;
        $netIncome = 0;
        for ($i = 0 ; $i <= 5; $i++) {
            $dates[] = $start->copy()->addMonth($i);
            
        }
        foreach ($dates as $key => $date) {
            $values = array(
                'date' => $date->format('F'),
                'dataMobil' => count(Report::where('jenis', 'Mobil')->where('status', '!=', 'Pending')->whereMonth('created_at', $date->format('m'))->whereYear('created_at', $date->format('Y'))->get()),
                'dataMotor' => count(Report::where('jenis', 'Sepeda Motor')->where('status', '!=', 'Pending')->whereMonth('created_at', $date->format('m'))->whereYear('created_at', $date->format('Y'))->get())
            );
            array_push($chartDatas, $values); 
        }
        return view('admin.index', compact('chartDatas', 'reportToday', 'reportMotor', 'reportMobil', 'reportDitemukan', 'reportAll'));
    }


// Admin Section
    public function admin(){
        $admins = Admin::all();
        $pelapor = Pelapor::all();
        return view('admin.admin', compact('admins','pelapor'));
    }

    public function addAdmin(){
        return view('admin.adminAdd');
    }

    public function storeAdmin(Request $request){
        $this->validate($request,[
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'nip' => 'required|numeric|unique:admins',
            'password' => 'required|string|min:8|confirmed',
        ]);
        $user = User::create([
            'email' => strtolower($request->email),
            'password' => bcrypt($request->password),
            'role' => 'admin',
            'status' => 'aktif'
        ]);
            $admin = Admin::create([
                'name' => $request->name,
                'nip' => $request->nip,
                'phone' => $request->phone,
                'userId' => $user->id,
            ]);
        
        
        return redirect()->route('adminData')->with('message','Admin Added Successfully!');
    }

    public function updatePelapor(Request $request, $id){
        $pelapor = Pelapor::findOrFail($id);
        $user = User::findOrFail($pelapor->userId);
        if($request->status == 'Active'){
            $user->status= "aktif";
        }elseif($request->status == 'Banned'){
            $user->status= "ditolak";
        }else{
            $user->status= "tidak aktif";
        }
        $user->save();
        return redirect()->route('adminData')->with('message','Pelapor Update Successfully!');
    }
//End Admin Section

//Laporan Section

    public function laporan()
    {
        $laporan = Report::latest()->get();
        return view('admin.laporan', compact('laporan')); 
    }
    public function addLaporan(){
        return view('admin.laporanAdd');
    }

    public function storeLaporan(Request $request){
        $this->validate($request,[
            'foto_stnk' => 'mimes:jpg,jpeg,png|required',
            'foto_bpkb' => 'mimes:jpg,jpeg,png|required',
            'foto_kendaraan' => 'mimes:jpg,jpeg,png|required',
        ]);
        $plat = strtolower(request('plat'));
        $str = strtolower(request('nama_kendaraan'));
        $no_hp = str_replace(str_split('+ '), '', $request->no_hp);
        
        $file = request('foto_stnk') ;
        $stnk = $file->getClientOriginalName() ;
        $destinationPath = public_path().'/img/stnk' ;
        $file->move($destinationPath,$stnk);
        
        $file = request('foto_bpkb') ;
        $bpkb = $file->getClientOriginalName() ;
        $destinationPath = public_path().'/img/bpkb' ;
        $file->move($destinationPath,$bpkb);

        $file = request('foto_kendaraan') ;
        $kendaraan = $file->getClientOriginalName() ;
        $destinationPath = public_path().'/img/kendaraan' ;
        $file->move($destinationPath,$kendaraan);

        $report = new Report;
        $report->nama_pemilik = $request->nama_pemilik;
        $report->user_id = auth()->user()->id;
        $report->no_hp = $no_hp;
        $report->nama_kendaraan = $request->nama_kendaraan;
        $report->jenis = $request->jenis;
        $report->warna = $request->warna;
        $report->foto_kendaraan = $kendaraan;
        $report->foto_stnk = $stnk;
        $report->foto_bpkb = $bpkb;
        $report->no_rangka = $request->no_rangka;
        $report->no_mesin = $request->no_mesin;
        $report->plat = $request->plat;
        $report->deskripsi = $request->deskripsi;
        $report->slug = preg_replace('/\s+/', '-', $str).'-'.preg_replace('/\s+/', '-', $plat).'-'.date('mY');
        $report->status = 'Pending';
        $report->save();

        return redirect()->route('pelapor.dashboard')->with('message','Laporan ditambah');
    }
    public function updatelaporan(Request $request, $id){
        $report = Report::findOrfail($id);
        if($report->status == 'Pending'){
            $report->status = 'Proses';
            $report->save();
        }elseif ($report->status == 'Proses') {
            $no_hp = $report->no_hp[2] == '0'?"+".str_replace('0','',$report->no_hp):"+$report->no_hp";
            $msg = 'Kami dari POLRES LHOKSEUMAWE ingin memberi informasi bahwasanya kendaraan atas nama ' .$report->nama_pemilik. ', dengan nomor polisi '.$report->plat.' sudah di temukan harap segera kekantor.';
            $report->status = 'Ditemukan';
            $report->save();
            if($report->status == 'Ditemukan'){
                // $this->sms($no_hp, $msg);
                SMS::send([$no_hp], 'Kami dari POLRES LHOKSEUMAWE ingin memberi informasi bahwasanya kendaraan atas nama ' .$report->nama_pemilik. ', dengan nomor polisi '.$report->plat.' sudah di temukan harap segera kekantor.');
            }
           
        }else{
            $report->status = 'Diambil';
            $report->save(); 
        }
        return redirect()->back()->with('message','Laporan diupdate');
    }

//End Laporan Section

    public function sms($hp, $msg)
    {
        $url = "https://semysms.net/api/3/sms.php"; //Url address for sending SMS
        $phone = $hp; // Phone number
        $msg = $msg;  // Message
        $device = '228727';  //  Device code
        $token = 'fb5a38ddc06e3aa34c053c0048c92d81';  //  Your token (secret)

        $data = array(
                "phone" => $phone,
                "msg" => $msg,
                "device" => $device,
                "token" => $token
            );

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);     
            $output = curl_exec($curl);
            curl_close($curl);
    }
}
