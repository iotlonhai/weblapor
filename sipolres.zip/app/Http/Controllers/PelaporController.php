<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pelapor;
use App\Report;
class PelaporController extends Controller
{
    public function index()
    {
        $laporan = Report::where('user_id', auth()->user()->id)->latest()->get();
        return view('pelapor.index', compact('laporan')); 
    }

    public function addLaporan(){
        return view('pelapor.laporanAdd');
    }

    public function storeLaporan(Request $request){
        $this->validate($request,[
            'foto_stnk' => 'mimes:jpg,jpeg,png|required',
            'foto_bpkb' => 'mimes:jpg,jpeg,png|required',
            'foto_kendaraan' => 'mimes:jpg,jpeg,png|required',
        ]);
        $plat = strtolower(request('plat'));
        $str = strtolower(request('nama_kendaraan'));
        $no_hp = str_replace(str_split('+ '), '', $request->no_hp);
        
        $file = request('foto_stnk') ;
        $stnk = $file->getClientOriginalName() ;
        $destinationPath = public_path().'/img/stnk' ;
        $file->move($destinationPath,$stnk);
        
        $file = request('foto_bpkb') ;
        $bpkb = $file->getClientOriginalName() ;
        $destinationPath = public_path().'/img/bpkb' ;
        $file->move($destinationPath,$bpkb);

        $file = request('foto_kendaraan') ;
        $kendaraan = $file->getClientOriginalName() ;
        $destinationPath = public_path().'/img/kendaraan' ;
        $file->move($destinationPath,$kendaraan);

        $report = new Report;
        $report->nama_pemilik = $request->nama_pemilik;
        $report->user_id = auth()->user()->id;
        $report->no_hp = $no_hp;
        $report->nama_kendaraan = $request->nama_kendaraan;
        $report->jenis = $request->jenis;
        $report->warna = $request->warna;
        $report->foto_kendaraan = $kendaraan;
        $report->foto_stnk = $stnk;
        $report->foto_bpkb = $bpkb;
        $report->no_rangka = $request->no_rangka;
        $report->no_mesin = $request->no_mesin;
        $report->plat = $request->plat;
        $report->deskripsi = $request->deskripsi;
        $report->slug = preg_replace('/\s+/', '-', $str).'-'.preg_replace('/\s+/', '-', $plat).'-'.date('mY');
        $report->status = 'Pending';
        $report->save();

        return redirect()->route('pelapor.dashboard')->with('message','Laporan ditambah');
    }

    public function destroyLaporan(Report $laporan){
        $foto_kendaraan = public_path().'/img/kendaraan/'.$laporan->foto_kendaraan;
        unlink($foto_kendaraan);
        $foto_stnk = public_path().'/img/stnk/'.$laporan->foto_stnk;
        unlink($foto_stnk);
        $foto_bpkb = public_path().'/img/bpkb/'.$laporan->foto_bpkb;
        unlink($foto_bpkb);
        $laporan -> delete();
        return redirect()->back()->with('message','Laporan dihapus');
    }

}
