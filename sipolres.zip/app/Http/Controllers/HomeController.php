<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Report;
use App\Admin;
use App\Pelapor;
use App\User;

class HomeController extends Controller
{
    
    public function index()
    {
        $reportMotor = Report::where('jenis', 'Sepeda Motor')->where('status', '!=', 'Pending')->latest()->get();
        $reportMobil = Report::where('jenis', 'Mobil')->where('status', '!=', 'Pending')->latest()->get();
        $reportDitemukan = Report::whereIn('status', ['Ditemukan', 'Diambil'])->latest()->get();
        $reportBelum = Report::where('status', 'Proses')->latest()->get();
        $reportAll = Report::where('status', '!=', 'Pending')->latest()->count();
        return view('welcome', compact('reportMotor', 'reportMobil', 'reportDitemukan', 'reportBelum'));
    }

    public function tentang()
    {
        return view('tentang');
    }

    public function search(Request $request)
    {
        $reports = Report::where('nama_kendaraan', 'like', '%' . $request->search . '%')
        ->orWhere('nama_pemilik', 'like', '%' . $request->search . '%')
        ->orWhere('plat', 'like', '%' . $request->search . '%')
        ->where('status', '!=', 'Pending')->get();
        return view('search', compact('reports'));
    }
    public function indexMotor()
    {
        $sepeda_motor = Report::where('jenis', 'Sepeda Motor')->where('status', '!=', 'Pending')->paginate(8);
        return view('motor', compact('sepeda_motor'));
    }

    public function showMotor($slug)
    {
        $motor = Report::where('slug', $slug)->firstOrFail();
        return view('motorShow', compact('motor'));
    }

    public function indexMobil()
    {
        $mobil = Report::where('jenis', 'Mobil')->where('status', '!=', 'Pending')->latest()->get();
        return view('mobil', compact('mobil'));
    }

    public function showMobil($slug)
    {
        $mobil = Report::where('slug', $slug)->firstOrFail();
        return view('mobilShow', compact('mobil'));
    }

    public function settingsAccount(){
        $admin = User::findOrFail(auth()->user()->id);
        return view('setting', compact('admin'));
    }

    public function updateAccount(Request $request){
        $user = User::findOrfail(auth()->user()->id);
        if(auth()->user()->role != 'spkt'){
            $level = Admin::where('userId',auth()->user()->id)->firstOrfail();
        }else{
            $level = Pelapor::where('userId',auth()->user()->id)->firstOrfail();
        }
        $this->validate($request,[
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . auth()->user()->id,
        ]);
        if($request->oldPassword == null){
            $user->update([
                'email' =>  strtolower($request->email),
            ]);
            $level->name = $request->name;
            $level->nip = $request->nip;
            $level->phone = $request->phone;
            $level->save();
            return redirect()->route(auth()->user()->role.'.dashboard')->with('message','Profile changed successfully!');
        }
        if (!(Hash::check($request->oldPassword, Auth::user()->password))) {
            return redirect()->back()->with("error","Your current password does not matches with the password you provided. Please try again.");
        }
        if(strcmp($request->oldPassword, $request->newPassword) == 0){
            return redirect()->back()->with("error","New Password cannot be same as your current password. Please choose a different password.");
        }
        $user->update([
            'email' =>  strtolower($request->email),
            'password' => bcrypt($request->newPassword),

        ]);
        $level->name = $request->name;
        $level->nip = $request->nip;
        $level->phone = $request->phone;
        $level->save();
            return redirect()->route(auth()->user()->role.'.dashboard')->with('message','Profile changed successfully!');
    }

}
