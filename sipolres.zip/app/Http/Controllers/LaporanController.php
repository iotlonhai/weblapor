<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Report;
use Storage;

class LaporanController extends Controller
{
    public function addLaporan(){
        return view('laporanAdd');
    }

    public function storeLaporan(Request $request){
        $this->validate($request,[
            'foto_stnk' => 'mimes:jpg,jpeg,png|required',
            'foto_bpkb' => 'mimes:jpg,jpeg,png|required',
            'foto_kendaraan' => 'mimes:jpg,jpeg,png|required',
        ]);
        
        $str = strtolower(request('nama_kendaraan'));
        $plat = strtolower(request('plat'));
        $no_hp = str_replace(str_split('+ '), '', $request->no_hp);
        
        $file = request('foto_stnk') ;
        $stnk = $file->getClientOriginalName() ;
        $destinationPath = public_path().'/img/stnk' ;
        $file->move($destinationPath,$stnk);
        
        $file = request('foto_bpkb') ;
        $bpkb = $file->getClientOriginalName() ;
        $destinationPath = public_path().'/img/bpkb' ;
        $file->move($destinationPath,$bpkb);

        $file = request('foto_kendaraan') ;
        $kendaraan = $file->getClientOriginalName() ;
        $destinationPath = public_path().'/img/kendaraan' ;
        $file->move($destinationPath,$kendaraan);

        $report = new Report;
        $report->nama_pemilik = $request->nama_pemilik;
        $report->no_hp = $no_hp;
        $report->nama_kendaraan = $request->nama_kendaraan;
        $report->jenis = $request->jenis;
        $report->warna = $request->warna;
        $report->foto_kendaraan = $kendaraan;
        $report->foto_stnk = $stnk;
        $report->foto_bpkb = $bpkb;
        $report->no_rangka = $request->no_rangka;
        $report->no_mesin = $request->no_mesin;
        $report->plat = $request->plat;
        $report->status = "Pending";
        $report->slug = preg_replace('/\s+/', '-', $str).'-'.preg_replace('/\s+/', '-', $plat).'-'.date('mY');
        $report->save();
        return redirect()->back()->with('message','Laporan ditambah');
    }
}
