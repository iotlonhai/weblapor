<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    protected $fillable = [
        'name', 'nip', 'phone', 'userId'
    ];
    public function admin_has_user()
    {
        return $this->belongsTo('App\User', 'userId');
    }
}
