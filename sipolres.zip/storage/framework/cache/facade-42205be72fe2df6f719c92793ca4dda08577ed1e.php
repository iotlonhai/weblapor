<?php

namespace Facades\Yugo\SMSGateway\Interfaces;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Yugo\SMSGateway\Interfaces\SMS
 */
class SMS extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'Yugo\SMSGateway\Interfaces\SMS';
    }
}
