<?php $__env->startSection('content'); ?>
<div class="uk-background-muted">
    <div class="uk-background-cover" style="background-position: 0% 60%;background-image: url('http://127.0.0.1:8000/img/depan.jpeg');" uk-height-viewport="offset-top: true">
        <div class="uk-align-center uk-padding uk-width-1-2@m" uk-scrollspy="cls: uk-animation-slide-left; repeat: false">
            <div class=" uk-text-center uk-border-rounded uk-overlay uk-overlay-primary">
                <h1>
                    <span style="color:#FDC42F">TURN BACK </span>
                    CRIME 
                </h1>
                <p class="uk-h3">TOGETHER WE CAN</p>
            </div>
            
        </div>
    </div>
    <div class="uk-container-small uk-align-center">
        <div class="uk-text-center">
            <div class="uk-child-width-expand@s uk-text-center uk-grid-match" uk-grid>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <p class="uk-h4">KENDARAAN MOTOR</p>
                        <hr style="border: 1px solid black">
                        <p class="uk-h4"><?php echo e(count($reportMotor)); ?></p>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <p class="uk-h4">KENDARAAN MOBIL</p>
                        <hr style="border: 1px solid black">
                        <p class="uk-h4"><?php echo e(count($reportMobil)); ?></p>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <p class="uk-h4">KASUS SELESAI</p>
                        <hr style="border: 1px solid black">
                        <p class="uk-h4"><?php echo e(count($reportDitemukan)); ?></p>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <p class="uk-h4">KASUS BERJALAN</p>
                        <hr style="border: 1px solid black">
                        <p class="uk-h4"><?php echo e(count($reportBelum)); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="uk-container">
        <p class="uk-text-center">
            <span class="uk-h2">TELAH HILANG</span><br>
        </p>
        <div class="uk-child-width-1-4@m uk-grid-match" uk-grid>
            <?php $__currentLoopData = $reportBelum->slice(0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-media-top">
                            <img src="<?php echo e(url('img/kendaraan',$rb->foto_kendaraan)); ?>" alt="">
                        </div>
                        <div class="uk-card-body">
                            <h3 class="uk-card-title"><?php echo e($rb->nama_kendaraan); ?></h3>
                            <p>
                                <b>Jenis: </b><?php echo e($rb->jenis); ?><br>
                                <b>Warna: </b><?php echo e($rb->warna); ?><br>
                                <b>No Polisi: </b><?php echo e($rb->plat); ?><br>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <hr>
    <div class="uk-margin uk-container">
        <p class="uk-text-center">
            <span class="uk-h2">TELAH DITEMUKAN</span><br>
        </p>
        <div class="uk-child-width-1-4@m uk-grid-match" uk-grid>
            <?php $__currentLoopData = $reportDitemukan->slice(0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-media-top">
                            <img src="<?php echo e(url('img/kendaraan',$rd->foto_kendaraan)); ?>" alt="">
                        </div>
                        <div class="uk-card-body">
                            <h3 class="uk-card-title"><?php echo e($rd->nama_kendaraan); ?></h3>
                            <p>
                                <b>Jenis: </b><?php echo e($rd->jenis); ?><br>
                                <b>Warna: </b><?php echo e($rd->warna); ?><br>
                                <b>No Polisi: </b><?php echo e($rd->plat); ?><br>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sipolres\resources\views/welcome.blade.php ENDPATH**/ ?>