<?php $__env->startSection('content'); ?>
        <a class="uk-button uk-button-text uk-align-right uk-margin-medium-right" href="<?php echo e(route('adminAddLaporan')); ?>"><span uk-icon="plus"></span> Add Laporan</a>
    </p>
    <h4 class="uk-text-center">DATA LAPORAN</h4>
    <div class="uk-overflow-auto">
        <table id="table" class="uk-table uk-table-striped uk-table-hover">
            <thead>
                <tr>
                    <th>Nama Kendaraan</th>
                    <th class="uk-visible@l">Jenis Kendaraan</th>
                    <th>No Polisi</th>
                    <th class="uk-width-small">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><button uk-toggle="target: #a<?php echo e(++$key); ?>" class="uk-align-left uk-button uk-button-text uk-text-center"><?php echo e($lapor->nama_kendaraan); ?></button></td>
                        <td class="uk-visible@l"><?php echo e($lapor->jenis); ?></td>
                        <td><?php echo e($lapor->plat); ?></td>
                        <td>
                        <a class="uk-text-primary uk-button uk-button-text" href="<?php echo e(route('adminEditLaporan',$lapor)); ?>">Update</a>
                            <form action="<?php echo e(route('adminDestroyLaporan', $lapor)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                                <?php echo e(method_field('DELETE')); ?>

                                <input class="uk-button uk-button-text uk-text-danger" type="submit" onclick="alert('Anda yakin hapus laporan dari <?php echo e($lapor->nama_pemilik); ?>?')" value="DELETE">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="a<?php echo e(++$key); ?>" uk-modal>
        <div class="uk-modal-dialog uk-modal-body">
            <button class="uk-modal-close-default" type="button" uk-close></button>
            <h2 class="uk-modal-title"><?php echo e($lapor->name); ?></h2>
            <div class="uk-child-width-1-2@m" uk-grid>
                <div class="uk-width-1-2">
                <img class="uk-border-rounded" src="<?php echo e(asset('img/kendaraan/'.$lapor->foto)); ?>" width="300" height="300" alt="Border pill">
                </div>
                <div class="uk-width-expand">
                    <p>
                        <b>Nama Kendaraan: </b><?php echo e($lapor->nama_kendaraan); ?><br>
                        <b>Jenis Kendaraan: </b><?php echo e($lapor->jenis); ?><br>
                        <b>Warna Kendaraan: </b><?php echo e($lapor->warna); ?><br>
                        <b>No Rangka: </b><?php echo e($lapor->no_rangka); ?><br>
                        <b>No Mesin: </b><?php echo e($lapor->no_mesin); ?><br>
                        <b>No Polisi: </b><?php echo e($lapor->plat); ?><br>
                        <b>Status: </b><?php echo e($lapor->status); ?><br>
                        <b>Deskripsi: </b><?php echo e($lapor->deskripsi); ?><br>
                    </p>
                </div>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/x/Documents/TGA/sipolres/resources/views/admin/kendaraan.blade.php ENDPATH**/ ?>