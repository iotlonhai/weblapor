<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(route('adminStoreLaporan')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="uk-margin uk-width-1-2@s">
        <div uk-form-custom>
            <input type="file" name="foto_stnk" required/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Foto STNK
            </button>
        </div>
        <div uk-form-custom>
            <input type="file" name="foto_bpkb" required/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Foto BPKB
            </button>
        </div>
        <div uk-form-custom>
            <input type="file" name="foto_kendaraan" required/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Foto Kendaraan
            </button>
        </div>
    </div>
    <div class="uk-grid-small" uk-grid>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Nama Pemilik</label>
            <input class="uk-input" name="nama_pemilik" type="text" placeholder="Saipudin" value="<?php echo e(old('nama_pemilik')); ?>" required/>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Hp Pemilik</label>
            <input class="uk-input  uk-width-expand" id="phname" name="no_hp" type="telp" placeholder="62813768xxxxx" value="<?php echo e(old('phname')); ?>" required/>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Nama Kendaraan</label>
            <input class="uk-input" name="nama_kendaraan" type="text" placeholder="Yamaha Mio" value="<?php echo e(old('nama_kendaraan')); ?>" required/>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Warna Kendaraan</label>
            <input class="uk-input" name="warna" type="text" placeholder="Merah" value="<?php echo e(old('warna')); ?>" required/>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Rangka</label>
            <input class="uk-input" name="no_rangka" type="text" placeholder="KNAFA32217539" value="<?php echo e(old('no_rangka')); ?>" required/>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Polisi</label>
            <input class="uk-input" name="plat" type="text" placeholder="BL 3321 NN" value="<?php echo e(old('plat')); ?>" required/>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Mesin</label>
            <input class="uk-input" name="no_mesin" type="text" placeholder="K10B76TF5111" value="<?php echo e(old('no_mesin')); ?>" required/>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Jenis Kendaraan</label>
            <select name="jenis" class="uk-select" required>
                <option value="">Pilih Jenis</option>
                <option value="Sepeda Motor">Sepeda Motor</option>
                <option value="Mobil">Mobil</option>
            </select>
        </div>
    </div>
    <div class="uk-margin">
        <label class="uk-form-label" for="form-stacked-text">Deskripsi</label>
        <textarea class="uk-textarea" name="deskripsi" rows="5" placeholder="Ceritakan kronologi kejadian pencurian" required></textarea>
    </div>
    <div class="uk-align-right">
        <input class="uk-button uk-button-kimia uk-margin-top uk-align-right" type="submit" value="Add">
    </div>
</form>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$().ready(() => {
  var maskOptions = {
    placeholder: "+62 ____________",
    onKeyPress: function(cep, e, field, options) {
      // Use an optional digit (9) at the end to trigger the change
      var masks = ["+62 00000000000", "+62 000000000000"],
        digits = cep.replace(/[^0-9]/g, "").length,
        // When you receive a value for the optional parameter, then you need to swap
        // to the new format
        mask = digits <= 12 ? masks[0] : masks[1];

      $("#phname").mask(mask, options);
    }
  };

  $("#phname").mask("+62 00000000000", maskOptions);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sipolres\resources\views/admin/laporanAdd.blade.php ENDPATH**/ ?>