<?php $__env->startSection('content'); ?>
        <a class="uk-button uk-button-text uk-align-right uk-margin-medium-right" href="<?php echo e(route('adminAdd')); ?>"><span uk-icon="plus"></span> Add User</a>
    </p>

    <h4 class="uk-text-center">DATA SPKT</h4>
    <ul uk-accordion>
        <li>
            <a class="uk-accordion-title" href="#">Admin</a>
            <div class="uk-accordion-content">
                <table class="uk-table uk-table-hover uk-table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>NIP</th>
                            <th>Email</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td class="uk-text-capitalize"><?php echo e($admin->name); ?></td>
                                <td><?php echo e($admin->nip); ?></td>
                                <td><?php echo e($admin->admin_has_user->email); ?></td>
                                <td><?php echo e($admin->phone); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </li>
        <li>
            <a class="uk-accordion-title" href="#">Pelapor</a>
            <div class="uk-accordion-content">
                <table class="uk-table uk-table-hover uk-table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>KTP</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pelapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><button uk-toggle="target: #a<?php echo e(++$key); ?>" class="uk-align-left uk-button uk-button-text uk-text-center"><?php echo e($lapor->name); ?></button></td>
                                <td class="uk-text-capitalize"><?php echo e($lapor->no_ktp); ?></td>
                                <td><?php echo e($lapor->pelapor_has_user->email); ?></td>
                                <td><?php echo e($lapor->phone); ?></td>
                                <td class="uk-text-capitalize"><?php echo e($lapor->pelapor_has_user->status); ?></td>
                                <td>
                                    <form action="<?php echo e(route('updatePelapor', $lapor)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('PUT')); ?>

                                            <input name="status" class="uk-button uk-button-text uk-text-success" type="submit" value="Active"><br>
                                            <input name="status" class="uk-button uk-button-text uk-text-danger" type="submit" value="Banned">
                                        </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </li>
    </ul>
    <?php $__currentLoopData = $pelapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="a<?php echo e(++$key); ?>" uk-modal>
        <div class="uk-border-rounded uk-modal-dialog uk-modal-body">
            <button class="uk-modal-close-default" type="button" uk-close></button>
            <h2 class="uk-modal-title"><?php echo e($lapor->name); ?></h2>
            <div class="uk-child-width-1-2@m" uk-grid>
                <div class="uk-width-medium">
                    <img src="<?php echo e(url('img/ktp/'.$lapor->foto_ktp)); ?>">
                </div>
                <div class="uk-width-expand">
                    <p>
                        <b>Nama: </b><?php echo e($lapor->name); ?><br>
                        <b>Nomor Ktp: </b><?php echo e($lapor->no_ktp); ?><br>
                        <b>Nomor Hp: </b><?php echo e($lapor->phone); ?><br>
                        <b>Alamat: </b><?php echo e($lapor->alamat); ?><br>
                        <b>Status: </b><?php echo e($lapor->pelapor_has_user->status); ?><br>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/x/Documents/TGA/sipolres/resources/views/admin/admin.blade.php ENDPATH**/ ?>