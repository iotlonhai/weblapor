<?php $__env->startSection('content'); ?>
<div class="uk-background-muted">
    <div class="uk-container uk-container-medium uk-padding uk-text-justify" style="font-size: 20px;line-height: 2.1;">
        <h1 class="uk-text-center">APA ITU LAPOR?</h1>
        <hr>
        <p>
            Pengelolaan pengaduan pelayanan publik bagian reskrim di setiap organisasi penyelenggara di Lhokseumawe belum terkelola secara efektif dan terintegrasi. Masing-masing organisasi penyelenggara mengelola pengaduan secara parsial dan tidak terkoordinir dengan baik. Akibatnya terjadi duplikasi penanganan pengaduan, atau bahkan bisa terjadi suatu pengaduan tidak ditangani oleh satupun organisasi penyelenggara,dengan alasan pengaduan bukan kewenangannya. Oleh karena itu, untuk mencapai visi dalam good governance maka perlu untuk mengintegrasikan sistem pengelolaan pengaduan pelayanan publik dalam satu pintu. Tujuannya, masyarakat memiliki satu saluran pengaduan secara Efektif. Untuk itu pihak reskrim POLRES Lhokseumawe khususnya bagian curanmor membentuk sistem pelaporan kendaraan hilang untuk memberikan pelayanan kepada pihak pelapor untuk menyampaikan data kendaraannya yang hilang. melalui website <b>www.fadel.sidangonline.pw</b></p>
            
        <p>
            Sistem ini dibentuk untuk merealisasikan kebijakan “no wrong door policy” yang menjamin hak masyarakat agar pengaduan terhadap kriminalitas curanmor disalurkan kepada pihak kepolisian yang berwenang menanganinya. 
        </p>

        <p>
            Tujuan sistem ini yaitu: <br>
            Pihak kepolisian dapat mengelola pengaduan dari masyarakat secara sederhana, cepat, tepat, tuntas, dan terkoordinasi dengan baik;<br>
            Masyarakat memberikan laporan dengan mudah dan cepat;<br>
            Meningkatkan kualitas pelayanan publik.        
        </p>
        <h1 class="uk-text-center">BAGAIMANA MELAPOR?</h1>
        <hr>
        <p>
            Cara melapor indikasi pencurian motor seperti berikut:
         <ul>
             <li>Pelapor terlebih dahulu melakukan pendaftaran pada menu register</li>
             <li>Setelah selesai mendaftar silahkan menunggu akun di verifikasi oleh admin kurang lebih 1x24 jam</li>
             <li>Jika akun sudah terverivikasi silahkan masukkan laporan anda dengan mengklik pada menu Add Laporan</li>
             <li>Input data kendaraan anda dengan benar dan akurat</li>
             <li>Loginlah seminggu sekali untuk melihat tracking pencarian kendaraan anda</li>
             <li>Anda akan menerima SMS oleh pihak kepolisan jika motor anda sudah ditemukan</li>
         </ul>
        </p>
       <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15894.086923678758!2d97.1222734!3d5.1803293!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa5c717aee3979a0f!2sPolres%20Lhokseumawe!5e0!3m2!1sid!2sid!4v1593353086208!5m2!1sid!2sid" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/x/Documents/TGA/sipolres/resources/views/tentang.blade.php ENDPATH**/ ?>