<?php $__env->startSection('content'); ?>
<div class="uk-text-right">
    <a href="<?php echo e(route('adminAddLaporan')); ?>" class="uk-button uk-button-text uk-border-rounded">Add Laporan</a>
    &nbsp;<a href="#" id="print" class="uk-button uk-button-primary uk-border-rounded">PRINT</a>
</div>
    
    </p>
    <h4 class="uk-text-center">DATA LAPORAN</h4>
    <div class="uk-overflow-auto">
        <table id="table" class="uk-table uk-table-striped uk-table-hover">
            <thead>
                <tr>
                    <th>Nama Pemilik</th>
                    <th class="uk-visible@l">Jenis Kendaraan</th>
                    <th>No Polisi</th>
                    <th>Tanggal Lapor</th>
                    <th class="uk-width-small">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($lapor->nama_pemilik); ?></td>
                        <td class="uk-visible@l"><?php echo e($lapor->jenis); ?></td>
                        <td><?php echo e($lapor->plat); ?></td>
                        <td><?php echo e($lapor->updated_at->format('d-F-Y')); ?></td>
                        <?php if($lapor->status == "Proses"): ?>
                        <td>
                            <form class="uk-margin-bottom" action="<?php echo e(route('adminUpdateLaporan', $lapor)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <input class="uk-button uk-button-primary  uk-width-1" type="submit" value="Di Temukan">
                            </form>
                            <a uk-toggle="target: #a<?php echo e(++$key); ?>" class="uk-align-left uk-button uk-button-text uk-width-1">
                                Detail
                            </a>
                        </td>
                        <?php elseif($lapor->status == "Pending"): ?>
                            <td>
                                <a uk-toggle="target: #a<?php echo e(++$key); ?>" class="uk-align-left uk-button uk-button-secondary uk-width-1">
                                    Laporan
                                </a>
                            </td>
                        <?php elseif($lapor->status == "Ditemukan"): ?>
                        <td>
                            <form class="uk-margin-bottom" action="<?php echo e(route('adminUpdateLaporan', $lapor)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <input class="uk-button uk-width-1" style="background-color: #46A049; color:#fff" type="submit" value="Di Ambil">
                            </form>
                            <a uk-toggle="target: #a<?php echo e(++$key); ?>" class="uk-align-left uk-button uk-button-text uk-width-1">
                                Detail
                            </a>
                        </td>
                        <?php else: ?>
                        <td class="uk-text-center">
                            <a uk-toggle="target: #a<?php echo e(++$key); ?>" class="uk-align-left uk-button uk-button-text uk-width-1">
                                Telah di ambil
                            </a>
                        </td>
                        <?php endif; ?>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="a<?php echo e(++$key); ?>" uk-modal>
        <div class="uk-border-rounded uk-modal-dialog uk-modal-body">
            <button class="uk-modal-close-default" type="button" uk-close></button>
            <h2 class="uk-modal-title"><?php echo e($lapor->name); ?></h2>
            <div class="uk-child-width-1-2@m" uk-grid>
                <div class="uk-width-medium">
                    <a href="<?php echo e(asset('img/kendaraan/'.$lapor->foto_kendaraan)); ?>" target="_blank" class="uk-button"> Foto Kendaraan</a><br>
                    <a href="<?php echo e(asset('img/stnk/'.$lapor->foto_stnk)); ?>" target="_blank" class="uk-button"> Foto STNK</a><br>
                    <a href="<?php echo e(asset('img/bpkb/'.$lapor->foto_bpkb)); ?>" target="_blank" class="uk-button"> Foto BPKB</a><br>
                </div>
                <div class="uk-width-expand">
                    <p>
                        <b>Nama Pemilik: </b><?php echo e($lapor->nama_pemilik); ?><br>
                        <b>No Hp Pemilik: </b><?php echo e($lapor->no_hp); ?><br>
                        <b>Nama Kendaraan: </b><?php echo e($lapor->nama_kendaraan); ?><br>
                        <b>Jenis Kendaraan: </b><?php echo e($lapor->jenis); ?><br>
                        <b>Warna Kendaraan: </b><?php echo e($lapor->warna); ?><br>
                        <b>No Rangka: </b><?php echo e($lapor->no_rangka); ?><br>
                        <b>No Mesin: </b><?php echo e($lapor->no_mesin); ?><br>
                        <b>No Polisi: </b><?php echo e($lapor->plat); ?><br>
                        <b>Status: </b><?php echo e($lapor->status); ?><br>
                    </p>
                </div>
                
                
            </div>
            <b>Deskripsi: </b><textarea class="uk-width-expand uk-height-small" style="color:black; border:0px; background-color:white;resize: none;" disabled><?php echo e($lapor->deskripsi); ?></textarea><br>
            <?php if($lapor->status == 'Pending'): ?>
            <div>
                <form action="<?php echo e(route('adminUpdateLaporan', $lapor)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <input class="uk-button uk-width-1" style="background-color: #46A049; color:#fff" type="submit" value="Proses">
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sipolres\resources\views/admin/laporan.blade.php ENDPATH**/ ?>