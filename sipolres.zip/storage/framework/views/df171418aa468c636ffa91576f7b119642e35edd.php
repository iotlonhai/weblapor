<?php $__env->startSection('content'); ?>
        <a class="uk-button uk-button-text uk-align-right uk-margin-medium-right" href="<?php echo e(route('pelaporAddLaporan')); ?>"><span uk-icon="plus"></span> Add Laporan</a>
    </p>
    <h4 class="uk-text-center">DATA LAPORAN</h4>
    <div class="uk-overflow-auto">
        <table id="table" class="uk-table uk-table-striped uk-table-hover">
            <thead>
                <tr>
                    <th>Nama Pelapor</th>
                    <th class="uk-visible@l">Jenis Kendaraan</th>
                    <th>No Polisi</th>
                    <th>Tanggal Lapor</th>
                    <th>Status</th>
                    <th class="uk-width-small">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><button uk-toggle="target: #a<?php echo e(++$key); ?>" class="uk-align-left uk-button uk-button-text uk-text-center"><?php echo e($lapor->nama_pemilik); ?></button></td>
                        <td class="uk-visible@l"><?php echo e($lapor->jenis); ?></td>
                        <td><?php echo e($lapor->plat); ?></td>
                        <td><?php echo e($lapor->created_at->format('d-F-Y')); ?></td>
                        <td><?php echo e($lapor->status); ?></td>
                        <td>
                            <form action="<?php echo e(route('pelaporDestroyLaporan', $lapor)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                                <?php echo e(method_field('DELETE')); ?>

                                <input class="uk-button uk-button-text uk-text-danger" type="submit" onclick="alert('Anda yakin hapus laporan dari <?php echo e($lapor->nama_pemilik); ?>?')" value="DELETE">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="a<?php echo e(++$key); ?>" class="uk-modal-container" uk-modal>
        <div class="uk-border-rounded uk-modal-dialog uk-modal-body">
            <button class="uk-modal-close-default" type="button" uk-close></button>
            <h2 class="uk-modal-title"><?php echo e($lapor->name); ?></h2>
            <div class="uk-child-width-1-2@m" uk-grid>
                <div class="uk-width-medium">
                    <a href="<?php echo e(asset('img/kendaraan/'.$lapor->foto_kendaraan)); ?>" target="_blank" class="uk-button"> Foto Kendaraan</a><br>
                    <a href="<?php echo e(asset('img/stnk/'.$lapor->foto_stnk)); ?>" target="_blank" class="uk-button"> Foto STNK</a><br>
                    <a href="<?php echo e(asset('img/bpkb/'.$lapor->foto_bpkb)); ?>" target="_blank" class="uk-button"> Foto BPKB</a><br>
                </div>
                <div class="uk-width-expand">
                    <p>
                        <b>Nama Pemilik: </b><?php echo e($lapor->nama_pemilik); ?><br>
                        <b>No Hp Pemilik: </b><?php echo e($lapor->no_hp); ?><br>
                        <b>Nama Kendaraan: </b><?php echo e($lapor->nama_kendaraan); ?><br>
                        <b>Jenis Kendaraan: </b><?php echo e($lapor->jenis); ?><br>
                        <b>Warna Kendaraan: </b><?php echo e($lapor->warna); ?><br>
                        <b>No Rangka: </b><?php echo e($lapor->no_rangka); ?><br>
                        <b>No Mesin: </b><?php echo e($lapor->no_mesin); ?><br>
                        <b>No Polisi: </b><?php echo e($lapor->plat); ?><br>
                        <b>Status: </b><?php echo e($lapor->status); ?><br>
                    </p>
                </div>
                
                
            </div>
            <b>Track: </b>
            <ol class="progtrckr" data-progtrckr-steps="4">
            <li class="progtrckr-done">Pending</li>
             <li class="<?php if($lapor->status == 'Proses' || $lapor->status == 'Ditemukan' || $lapor->status == 'Diambil' ): ?> progtrckr-done <?php else: ?> progtrckr-todo <?php endif; ?>">Proses</li>
             <li class="<?php if($lapor->status == 'Ditemukan' || $lapor->status == 'Diambil'): ?> progtrckr-done <?php else: ?> progtrckr-todo <?php endif; ?>">Di Temukan</li>
             <li class="<?php if($lapor->status == 'Diambil'): ?> progtrckr-done <?php else: ?> progtrckr-todo <?php endif; ?>"">Di Ambil</li>
            </ol>
            <br>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sipolres\resources\views/pelapor/index.blade.php ENDPATH**/ ?>