<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(route('spktStoreLaporan')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="uk-margin uk-width-1-2@s">
        <div uk-form-custom>
            <input type="file" name="foto_stnk"/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Foto STNK
            </button>
        </div>
        <div uk-form-custom>
            <input type="file" name="foto_bpkb"/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Foto BPKB
            </button>
        </div>
        <div uk-form-custom>
            <input type="file" name="foto_kendaraan"/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Foto Kendaraan
            </button>
        </div>
    </div>
    <div class="uk-grid-small" uk-grid>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Nama Pemilik</label>
            <input class="uk-input" name="nama_pemilik" type="text" placeholder="Saipudin" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Hp Pemilik</label>
            <input class="uk-input  uk-width-expand" id="phname" name="no_hp" type="telp" placeholder="62813768xxxxx" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Nama Kendaraan</label>
            <input class="uk-input" name="nama_kendaraan" type="text" placeholder="Yamaha Mio" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Warna Kendaraan</label>
            <input class="uk-input" name="warna" type="text" placeholder="Merah" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Rangka</label>
            <input class="uk-input" name="no_rangka" type="text" placeholder="KNAFA32217539" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Polisi</label>
            <input class="uk-input" name="plat" type="text" placeholder="BL 3321 NN" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Mesin</label>
            <input class="uk-input" name="no_mesin" type="text" placeholder="K10B76TF5111" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Jenis Kendaraan</label>
            <select name="jenis" class="uk-select">
                <option>Pilih Jenis</option>
                <option value="Sepeda Motor">Sepeda Motor</option>
                <option value="Mobil">Mobil</option>
            </select>
        </div>
        <div class="uk-width-1@s">
            <label class="uk-form-label" for="form-stacked-text">Description</label>
            <textarea name="deskripsi" class="uk-textarea" id="" rows="7"></textarea>
        </div>
    </div>
    <div class="uk-align-right">
        <input class="uk-button uk-button-kimia uk-margin-top uk-align-right" type="submit" value="Add">
    </div>
</form>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js'></script>
<script>
    $('#phname').mask('+62 99999999999');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/x/Documents/TGA/sipolres/resources/views/spkt/laporanAdd.blade.php ENDPATH**/ ?>