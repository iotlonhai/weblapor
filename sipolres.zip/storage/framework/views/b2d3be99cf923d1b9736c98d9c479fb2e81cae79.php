<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/uikit.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/uikit-icons.min.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/uikit.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.uikit.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.uikit.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
</head>

<body>
        <nav class="uk-navbar-container" uk-navbar>
            <div class="nav-overlay uk-navbar-left">
                <a class="uk-navbar-item uk-logo" href="<?php echo e(route('home')); ?>">POLRES</a>

                <ul class="uk-navbar-nav">
                    <li><a href="<?php echo e(route('indexMotor')); ?>">Motor</a></li>
                    <li><a href="<?php echo e(route('indexMobil')); ?>">Mobil</a></li>
                    <li><a href="<?php echo e(route('tentang')); ?>">Tentang</a></li>
                </ul>
            </div>
            <div class="uk-navbar-right uk-margin-medium-right">
                <ul class="uk-navbar-nav">
                    <?php if(auth()->guard()->check()): ?>
                    <li><a class="uk-text-bold" href="<?php echo e(route(auth()->user()->role.'.dashboard')); ?>">Dashboard</a></li>
                    <?php else: ?>
                    <li><a class="uk-text-bold" href="<?php echo e(route('login')); ?>">Login</a></li>
                    <li><a class="uk-text-bold" href="<?php echo e(route('register')); ?>">Register</a></li>

                    <?php endif; ?>
                </ul>

                <div class="nav-overlay uk-navbar-right">

                    <a class="uk-navbar-toggle" uk-search-icon uk-toggle="target: .nav-overlay; animation: uk-animation-fade" href="#"></a>
            
                </div>
            
                <div class="nav-overlay uk-navbar-left uk-flex-1" hidden>
            
                    <div class="uk-navbar-item uk-width-expand">
                        <form action="<?php echo e(route('search')); ?>" class="uk-search uk-search-navbar uk-width-1-1">
                            <input class="uk-search-input" name="search" type="search" placeholder="Search..." autofocus>
                        </form>
                    </div>
            
                    <a class="uk-navbar-toggle" uk-close uk-toggle="target: .nav-overlay; animation: uk-animation-fade" href="#"></a>
            
                </div>
            </div>   
        </nav>
       
            
        <?php echo $__env->yieldContent('content'); ?>
        <?php if(\Session::has('message')): ?>
        <script>
            $(function() {
                UIkit.modal.dialog(`
                <div class="uk-padding uk-text-center">
                    <p class="uk-h3">Laporan anda telah kami terima, mohon untuk segera kunjungi POLRES LHOKSEUMAWE dalam tempo waktu 3x24 jam</p>
                    </div>`)
            });
            </script>
        <?php endif; ?>
        <footer class="uk-background-secondary uk-text-center uk-light">
            <span>
                &copy; 2020. Fadel Irawan. Sistem Informasi Pelaporan Kehilangan Kendaraan
            </span>
        </footer>
</body>

</html><?php /**PATH E:\sipolres\resources\views/layouts/home.blade.php ENDPATH**/ ?>