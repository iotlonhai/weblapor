<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="/css/uikit.min.css">
    <script src="/js/uikit.min.js"></script>
    <script src="/js/uikit-icons.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
</head>
<body style="background: #000">
    <div class="uk-visible@l uk-background-contain" style="background: url('http://127.0.0.1:8000/img/polri.png'); background-repeat: no-repeat; background-position: 10%;" uk-height-viewport="offset-bottom: true" uk-grid>
        <?php if($errors->any()): ?>
        <div class="uk-align-center uk-padding">
            <div class="uk-alert-danger" uk-alert>
                <a class="uk-alert-close" uk-close></a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>    
        </div>
        <?php endif; ?>
        <div class="uk-padding uk-position-center-right" >
            <div class="uk-text-center uk-border-rounded uk-card-large uk-card uk-card-default uk-padding uk-card-hover" style="background: #FDC42F">
                <h3 class="uk-text-center">Sign Up</h3>
                <p>Sign up and create your report!</p>
                <form class="uk-light" method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="uk-margin">
                        <input class="uk-input <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> uk-form-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" type="text" placeholder="Nama Sesuai KTP" value="<?php echo e(old('name')); ?>" autocomplete="off" required>
                    </div>
                    <div class="uk-margin">
                            <input class="uk-input <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> uk-form-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" type="email" placeholder="Email Login" value="<?php echo e(old('email')); ?>" autocomplete="off" required>
                    </div>
                    <div class="uk-margin">
                            <input class="uk-input <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> uk-form-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phname" name="phone" type="phone" placeholder="Nomor Hp" value="<?php echo e(old('phone')); ?>" autocomplete="off" required>
                    </div>
                    <div class="uk-margin">
                        <input class="uk-input <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?> uk-form-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="alamat" type="text" placeholder="Alamat sesuai KTP" value="<?php echo e(old('alamat')); ?>" autocomplete="off" required>
                </div>
                    <div class="uk-margin">
                            <input class="uk-input <?php if ($errors->has('no_ktp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_ktp'); ?> uk-form-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="no_ktp" type="number" placeholder="Nomor KTP" value="<?php echo e(old('no_ktp')); ?>" autocomplete="off" required>
                    </div>
                    <div class="uk-margin">
                        <div uk-form-custom="target: true">
                            <input name="foto_ktp" type="file" required>
                            <input class="uk-input uk-form-width-medium" type="text" placeholder="Foto KTP" disabled>
                            <button class="uk-button uk-button-default">Pilih</button>
                        </div>
                    </div>
                    <div class="uk-margin">
                            <input class="uk-input <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> uk-form-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" type="password" placeholder="Password" required>
                    </div>
                    <div class="uk-margin">
                            <input class="uk-input <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> uk-form-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password_confirmation" type="password" placeholder="Ketik Ulang Password" required>
                    </div>
                    <div class="uk-margin">
                            <input class="uk-button uk-button-default uk-border-rounded" type="submit" value="Sign Up">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <script>
    $().ready(() => {
    var maskOptions = {
        placeholder: "+62 ____________",
        onKeyPress: function(cep, e, field, options) {
        // Use an optional digit (9) at the end to trigger the change
        var masks = ["+62 00000000000", "+62 000000000000"],
            digits = cep.replace(/[^0-9]/g, "").length,
            // When you receive a value for the optional parameter, then you need to swap
            // to the new format
            mask = digits <= 12 ? masks[0] : masks[1];

        $("#phname").mask(mask, options);
        }
    };

    $("#phname").mask("+62 00000000000", maskOptions);
    });
    </script>
</body>
</html><?php /**PATH E:\sipolres\resources\views/auth/register.blade.php ENDPATH**/ ?>