<?php $__env->startSection('content'); ?>
<div class="uk-background-muted">
    <div class="uk-container uk-padding">
        <p class="uk-text-center">
            <span class="uk-h2">HASIL PENCARIAN</span><hr><br>
        </p>
        <div class="uk-child-width-1-4@m uk-grid-match" uk-grid>
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-media-top">
                            <img src="<?php echo e(url('img/kendaraan',$report->foto_kendaraan)); ?>" alt="">
                        </div>
                        <div class="uk-card-body">
                            <h3 class="uk-card-title"><?php echo e($report->nama_kendaraan); ?></h3>
                            <p>
                                <b>Jenis: </b><?php echo e($report->jenis); ?><br>
                                <b>Warna: </b><?php echo e($report->warna); ?><br>
                                <b>No Polisi: </b><?php echo e($report->plat); ?><br>
                            </p>
                            <?php if($report->status == 'Belum Ditemukan'): ?>
                                <span class="uk-label uk-label-danger"><?php echo e($report->status); ?></span>
                            <?php else: ?>
                                <span class="uk-label"><?php echo e($report->status); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sipolres\resources\views/search.blade.php ENDPATH**/ ?>