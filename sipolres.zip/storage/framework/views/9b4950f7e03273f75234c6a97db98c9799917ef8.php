<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(route('adminUpdateLaporan', $laporan->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PUT')); ?>

    <div class="uk-width-1-2@s">
        <div uk-form-custom>
            <input type="file" name="surat"/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Surat SPKT
            </button>
        </div>
        <div uk-form-custom>
            <input type="file" name="foto_stnk"/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Foto STNK
            </button>
        </div>
        <div uk-form-custom>
            <input type="file" name="foto_bpkb"/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Foto BPKB
            </button>
        </div>
    </div>
    <div class="uk-margin">
        <div uk-form-custom>
            <img src="<?php echo e(asset('img/kendaraan/'.$laporan->foto_kendaraan)); ?>" class="rounded uk-margin-small-right"/>
            <input type="file" name="image"/>
            <button class="uk-button uk-button-default" type="button" tabindex="-1">
                Select
            </button>
        </div>
    </div>
    <div class="uk-grid-small" uk-grid>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Nama Pemilik</label>
            <input class="uk-input" name="nama_pemilik" type="text" value="<?php echo e($laporan->nama_pemilik); ?>" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Hp Pemilik</label>
            <input class="uk-input  uk-width-expand" id="phname" name="no_hp" type="telp" value="<?php echo e($laporan->no_hp); ?>" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Nama Kendaraan</label>
            <input class="uk-input" name="nama_kendaraan" type="text" value="<?php echo e($laporan->nama_kendaraan); ?>" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Warna Kendaraan</label>
            <input class="uk-input" name="warna" type="text" value="<?php echo e($laporan->warna); ?>" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Rangka</label>
            <input class="uk-input" name="no_rangka" type="text" value="<?php echo e($laporan->no_rangka); ?>" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Polisi</label>
            <input class="uk-input" name="plat" type="text" value="<?php echo e($laporan->plat); ?>" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">No Mesin</label>
            <input class="uk-input" name="no_mesin" type="text" value="<?php echo e($laporan->no_mesin); ?>" />
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Jenis Kendaraan</label>
            <select name="jenis" class="uk-select">
                <option value="Sepeda Motor" <?php if($laporan->jenis == "Sepeda Motor"): ?> selected <?php endif; ?>>Sepeda Motor</option>
                <option value="Mobil" <?php if($laporan->jenis == "Mobil"): ?> selected <?php endif; ?>>Mobil</option>
            </select>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Status Kendaraan</label>
            <select name="status" class="uk-select">
                <option value="Pending" <?php if($laporan->status == "Pending"): ?> selected <?php endif; ?>>Pending</option>
                <option value="Belum Ditemukan" <?php if($laporan->status == "Belum Ditemukan"): ?> selected <?php endif; ?>>Belum Ditemukan</option>
                <option value="Ditemukan" <?php if($laporan->status == "Ditemukan"): ?> selected <?php endif; ?>>Ditemukan</option>
            </select>
        </div>
        <div class="uk-width-1-2@s">
            <label class="uk-form-label" for="form-stacked-text">Description</label>
            <textarea name="deskripsi" class="uk-textarea" id="" rows="7" wrap="hard"><?php echo e($laporan->deskripsi); ?></textarea>
        </div>
    </div>
    <div class="uk-align-right">
        <input class="uk-button uk-button-kimia uk-margin-top uk-align-right" type="submit" value="Update">
    </div>
</form>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js'></script>
<script>
    $('#phname').mask('+62 99999999999');
    $("textarea").on("change", function(event){
    $this.replace(/\n\r?/g, '\n');
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/x/Documents/TGA/sipolres/resources/views/admin/laporanEdit.blade.php ENDPATH**/ ?>