<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="uk-position-center uk-padding-large">
    <h3 class="uk-text-uppercase">UPDATE <?php echo e($admin->name); ?></h3>
    <form action="<?php echo e(route('updateAccount')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <div class="uk-grid-small" uk-grid>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">Name</label>
            <input class="uk-input" name="name" type="text" value="<?php echo e($admin->user_has_admin->name); ?>" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">Email Address</label>
                <input class="uk-input" name="email" type="text" value="<?php echo e($admin->email); ?>" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">NIP</label>
                <input class="uk-input" name="nip" type="text" value="<?php echo e($admin->user_has_admin->nip); ?>" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">Phone</label>
                <input class="uk-input" name="phone" type="text" value="<?php echo e($admin->user_has_admin->phone); ?>" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">Old Password</label>
                <input class="uk-input" name="oldPassword" type="password" placeholder="Old Password" />
            </div>
            <div class="uk-width-1-2@s">
                <label class="uk-form-label" for="form-stacked-text">New Password</label>
                <input type="password" class="uk-input" name="newPassword" placeholder="New Password">
            </div>
            <div class="uk-width-1-2@s">
                <input class="uk-button uk-button-kimia uk-margin-top uk-align-right" type="submit" value="Add">
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/x/Documents/TGA/sipolres/resources/views/setting.blade.php ENDPATH**/ ?>