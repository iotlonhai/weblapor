<?php $__env->startSection('content'); ?>
<div class="uk-background-muted">
    <div class="uk-container uk-padding">
        <p class="uk-text-center">
            <span class="uk-h2">SEPEDA MOTOR</span><br>
        </p>
        <div class="uk-child-width-1-4@m uk-grid-match" uk-grid>
            <?php $__currentLoopData = $sepeda_motor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sepmor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-media-top">
                            <img src="<?php echo e(url('img/kendaraan',$sepmor->foto_kendaraan)); ?>" alt="">
                        </div>
                        <div class="uk-card-body">
                            <h3 class="uk-card-title"><?php echo e($sepmor->nama_kendaraan); ?></h3>
                            <p>
                                <b>Jenis: </b><?php echo e($sepmor->jenis); ?><br>
                                <b>Warna: </b><?php echo e($sepmor->warna); ?><br>
                                <b>No Polisi: </b><?php echo e($sepmor->plat); ?><br>
                            </p>
                            <?php if($sepmor->status == 'Belum Ditemukan'): ?>
                                <span class="uk-label uk-label-danger"><?php echo e($sepmor->status); ?></span>
                            <?php else: ?>
                                <span class="uk-label"><?php echo e($sepmor->status); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="uk-padding uk-align-right">

            <?php echo e($sepeda_motor->links()); ?>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/x/Documents/TGA/sipolres/resources/views/motor.blade.php ENDPATH**/ ?>