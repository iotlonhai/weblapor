<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="uk-position-center uk-padding-large">
    <h3>ADD USER</h3>
        <form action="<?php echo e(route('adminStore')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="uk-grid-small" uk-grid>
                <div class="uk-width-1-2@s">
                    <label class="uk-form-label" for="form-stacked-text">Name</label>
                    <input class="uk-input" name="name" type="text" placeholder="John Doe" />
                </div>
                <div class="uk-width-1-2@s">
                    <label class="uk-form-label" for="form-stacked-text">Email Address</label>
                    <input class="uk-input" name="email" type="text" placeholder="admin@mail.com" />
                </div>
                <div class="uk-width-1-2@s">
                    <label class="uk-form-label" for="form-stacked-text">NIP</label>
                    <input class="uk-input" name="nip" type="text" placeholder="11223344556677" />
                </div>
                <div class="uk-width-1-2@s">
                    <label class="uk-form-label" for="form-stacked-text">Phone</label>
                    <input class="uk-input" name="phone" type="text" placeholder="081234567898" />
                </div>
                <div class="uk-width-1-2@s">
                    <label class="uk-form-label" for="form-stacked-text">Password</label>
                    <input class="uk-input" name="password" type="password" placeholder="Password" />
                </div>
                <div class="uk-width-1-2@s">
                    <label class="uk-form-label" for="form-stacked-text">Password Confirmation</label>
                    <input id="password-confirm" type="password" class="uk-input" name="password_confirmation" required placeholder="Password Confirmation">
                </div>
                <div class="uk-width-1-2@s">
                    <input class="uk-button uk-button-kimia uk-margin-top uk-align-right" type="submit" value="Add">
                </div>
            </div>
        </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/x/Documents/TGA/sipolres/resources/views/admin/adminAdd.blade.php ENDPATH**/ ?>